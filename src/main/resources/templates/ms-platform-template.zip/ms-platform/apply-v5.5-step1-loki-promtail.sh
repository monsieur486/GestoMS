#!/usr/bin/env bash
set -euo pipefail

echo "Applying V5.5 step1 Loki/Promtail patch..."

if [ ! -f docker-compose.yml ]; then
  echo "ERROR: docker-compose.yml not found. Run this script from ms-platform root."
  exit 1
fi

mkdir -p observability/promtail

cat > observability/promtail/promtail-config.yml <<'EOF'
server:
  http_listen_port: 9080
  grpc_listen_port: 0

positions:
  filename: /tmp/positions.yaml

clients:
  - url: http://loki:3100/loki/api/v1/push

scrape_configs:
  - job_name: docker
    docker_sd_configs:
      - host: unix:///var/run/docker.sock
        refresh_interval: 5s

    relabel_configs:
      - source_labels: ['__meta_docker_container_name']
        target_label: 'container'
      - source_labels: ['__meta_docker_container_label_com_docker_compose_service']
        target_label: 'service'
EOF

python3 <<'PY'
from pathlib import Path
import re

compose = Path("docker-compose.yml")
text = compose.read_text()

loki_block = '''
  loki:
    image: grafana/loki:3.2.1
    command: -config.file=/etc/loki/local-config.yaml
    ports:
      - "3100:3100"
    healthcheck:
      test: ["CMD-SHELL", "wget -qO- http://localhost:3100/ready || exit 1"]
      interval: 10s
      timeout: 5s
      retries: 20

  promtail:
    image: grafana/promtail:3.2.1
    volumes:
      - /var/lib/docker/containers:/var/lib/docker/containers:ro
      - /var/run/docker.sock:/var/run/docker.sock:ro
      - ./observability/promtail/promtail-config.yml:/etc/promtail/config.yml:ro
    command: -config.file=/etc/promtail/config.yml
    depends_on:
      loki:
        condition: service_healthy
'''

if "  loki:" not in text:
    match = re.search(r"\n(volumes|networks):\n", text)
    if match:
        text = text[:match.start()] + loki_block + "\n" + text[match.start():]
    else:
        text = text.rstrip() + "\n" + loki_block + "\n"

compose.write_text(text)
PY

BW="service-batch/src/main/java/com/mr486/msplatform/batch/service/BatchWorker.java"

if [ -f "$BW" ]; then
python3 <<'PY'
from pathlib import Path
import re

path = Path("service-batch/src/main/java/com/mr486/msplatform/batch/service/BatchWorker.java")
text = path.read_text()

if "import lombok.extern.slf4j.Slf4j;" not in text:
    text = text.replace("import lombok.RequiredArgsConstructor;", "import lombok.RequiredArgsConstructor;\nimport lombok.extern.slf4j.Slf4j;")

if "@Slf4j" not in text:
    text = text.replace("@Service\n@RequiredArgsConstructor", "@Service\n@RequiredArgsConstructor\n@Slf4j")
    text = text.replace("@Component\n@RequiredArgsConstructor", "@Component\n@RequiredArgsConstructor\n@Slf4j")

completion_log = '''
        log.warn(
                "event=BATCH_COMPLETED jobId={} totalSeconds={} averageSeconds={} generatedCount={} instance={}",
                response.jobId(),
                response.totalSeconds(),
                response.averageSeconds(),
                response.generatedCount(),
                response.instance()
        );
'''

if "event=BATCH_COMPLETED" not in text:
    if "store.save(response);" in text:
        text = text.replace("store.save(response);", "store.save(response);\n" + completion_log, 1)
    elif "redisJobStore.save(response);" in text:
        text = text.replace("redisJobStore.save(response);", "redisJobStore.save(response);\n" + completion_log, 1)
    else:
        marker = "rabbitTemplate.convertAndSend"
        idx = text.find(marker)
        if idx != -1:
            text = text[:idx] + completion_log + "\n        " + text[idx:]

if "event=BATCH_FAILED" not in text:
    text = re.sub(
        r"catch\s*\(\s*Exception\s+(\w+)\s*\)\s*\{",
        r'''catch (Exception \1) {
            log.error(
                    "event=BATCH_FAILED jobId={} attempt={} error={}",
                    message.jobId(),
                    message.attempt(),
                    \1.getMessage()
            );''',
        text,
        count=1
    )

path.write_text(text)
PY
else
  echo "WARN: $BW not found. Skipping BatchWorker log injection."
fi

cat > observability/README.md <<'EOF'
# Observability V5.5 step1

This patch adds Loki + Promtail.

## Start

```bash
docker compose up -d loki promtail
```

or restart the full stack:

```bash
docker compose down
./prod-start.sh
```

## Test Loki

Run a few batch jobs:

```bash
./test-all.sh
source tokens.env
./benchmark-async-batch.sh 10 5
```

Query Loki:

```bash
curl -G http://localhost:3100/loki/api/v1/query_range \
  --data-urlencode 'query={service="service-batch"} |= "BATCH_COMPLETED"'
```

Expected log marker:

```txt
event=BATCH_COMPLETED
```
EOF

echo "Patch applied."
echo ""
echo "Next:"
echo "  docker compose up -d --build --force-recreate service-batch loki promtail"
echo "  ./test-all.sh"
echo "  source tokens.env"
echo "  ./benchmark-async-batch.sh 10 5"
echo ""
echo "Query:"
echo "  curl -G http://localhost:3100/loki/api/v1/query_range --data-urlencode 'query={service="service-batch"} |= "BATCH_COMPLETED"'"

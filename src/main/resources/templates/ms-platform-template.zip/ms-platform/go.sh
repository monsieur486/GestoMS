sed -i 's#http://service-a#lb://service-a#g' service-consumer/src/main/java/com/mr486/msplatform/consumer/controller/AggregateController.java
sed -i 's#http://service-b#lb://service-b#g' service-consumer/src/main/java/com/mr486/msplatform/consumer/controller/AggregateController.java
sed -i 's#http://service-c#lb://service-c#g' service-consumer/src/main/java/com/mr486/msplatform/consumer/controller/AggregateController.java

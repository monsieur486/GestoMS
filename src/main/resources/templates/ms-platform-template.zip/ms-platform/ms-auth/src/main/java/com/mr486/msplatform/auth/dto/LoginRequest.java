package com.mr486.msplatform.auth.dto;
import lombok.Getter;import lombok.NoArgsConstructor;import lombok.AllArgsConstructor;
@Getter @NoArgsConstructor @AllArgsConstructor
public class LoginRequest {
    private String username;
    private String password;
}

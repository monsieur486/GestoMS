package com.mr486.msplatform.consumer.listener;

import com.mr486.msplatform.consumer.dto.BatchNotification;
import lombok.RequiredArgsConstructor;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class BatchNotificationListener {

    private final SimpMessagingTemplate messagingTemplate;

    @RabbitListener(queues = "batch.notifications")
    public void onNotification(BatchNotification notification) {
        messagingTemplate.convertAndSend("/topic/batch", notification);
        messagingTemplate.convertAndSend("/topic/batch/" + notification.jobId(), notification);
    }
}

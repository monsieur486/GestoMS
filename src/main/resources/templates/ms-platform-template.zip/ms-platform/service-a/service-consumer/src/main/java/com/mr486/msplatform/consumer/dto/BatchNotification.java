package com.mr486.msplatform.consumer.dto;

public record BatchNotification(
        String jobId,
        String status,
        int generatedCount,
        double totalSeconds,
        String instance
) {
}

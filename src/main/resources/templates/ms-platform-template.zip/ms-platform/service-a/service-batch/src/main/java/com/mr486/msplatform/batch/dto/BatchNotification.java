package com.mr486.msplatform.batch.dto;

public record BatchNotification(
        String jobId,
        String status,
        int generatedCount,
        double totalSeconds,
        String instance
) {
}
